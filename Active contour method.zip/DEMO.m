
J = imread(['dataset/' 'gaussian_0.015nonHom3.bmp']);

 
if size(J,3)==3
    J_t=J;
    J=J(:,:,1);
end

mask = false(size(J,1),size(J,2));   %-- create initial mask

%%---------------
mask(30:59,24:39)=true;
mask = logical(mask);


%% initialize mask
mask_init=mask;
%% run Our method
tic
seg1 = LSM_TEST(double(J),mask_init);
toc

