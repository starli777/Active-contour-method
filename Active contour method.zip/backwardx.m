function [dx]=backwardx(u,Ny,Nx);

dx = u;
dx(2:Ny-1,2:Nx-1)=( u(2:Ny-1,2:Nx-1) - u(2:Ny-1,1:Nx-2) );
%dx(:,1) = u(:,1);
dx(:,Nx) = -u(:,Nx-1);