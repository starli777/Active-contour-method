function [dy]=backwardy(u,Ny,Nx);

dy = u;
dy(2:Ny-1,2:Nx-1)=( u(2:Ny-1,2:Nx-1) - u(1:Ny-2,2:Nx-1) );
%dy(1,:) = u(1,:);
dy(Ny,:) = -u(Ny-1,:);